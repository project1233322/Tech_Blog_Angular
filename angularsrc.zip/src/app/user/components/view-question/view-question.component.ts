import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field'
import { QuestionService } from '../../user-services/question-service/question.service';
import { ActivatedRoute } from '@angular/router';
import { MatChipsModule } from '@angular/material/chips';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { StorageServiceService } from '../../../service/storage-service/storage-service.service';
import { AnswerService } from '../../user-services/answer-services/answer.service';

@Component({
  selector: 'app-view-question',
  standalone: true,
  imports: [CommonModule, MatFormFieldModule,MatChipsModule, ReactiveFormsModule, MatInputModule,MatButtonModule],
  templateUrl: './view-question.component.html',
  styleUrl: './view-question.component.scss'
})
export class ViewQuestionComponent {

questionId: number =this.activatedRoute.snapshot.params["questionId"]
question : any;
validateForm!: FormGroup; 

constructor(
  private questionService : QuestionService, 
  private activatedRoute : ActivatedRoute,
  private answerService: AnswerService,
  private fb: FormBuilder
) { }

ngOnInit()
{
  
  this.validateForm = this.fb.group({
    body:[null, Validators.required]
  })
  this.getQuestionById();
}

getQuestionById()
{
  this.questionService.getQuestionById(this.questionId).subscribe(
    (res)=>{
      
      this.question=res.questionDTO;
     
    }
  )
}

addAnswer(){
  console.log(this.validateForm.value)
  const data = this.validateForm.value;
  data.questionId=this.questionId;
  data.userId = StorageServiceService.getUserId();
  
  this.answerService.postAnswer(data).subscribe((res)=>{
    console.log(res);
  })
}

}
